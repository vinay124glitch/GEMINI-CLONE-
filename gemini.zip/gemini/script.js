let tabs = [];
let currentTabIndex = 0;

function saveTabs() {
  localStorage.setItem("tabs", JSON.stringify(tabs));
}

function loadTabs() {
  const saved = localStorage.getItem("tabs");
  if (saved) tabs = JSON.parse(saved);
  else createNewTab();
}

function createNewTab() {
  const newTab = {
    id: Date.now(),
    name: `Chat ${tabs.length + 1}`,
    messages: []
  };
  tabs.push(newTab);
  currentTabIndex = tabs.length - 1;
  renderTabs();
  renderMessages();
  saveTabs();
}

function renameTab() {
  const newName = prompt("Enter new tab name:");
  if (newName) {
    tabs[currentTabIndex].name = newName;
    renderTabs();
    saveTabs();
  }
}

function closeCurrentTab() {
  if (tabs.length <= 1) {
    alert("You must have at least one tab.");
    return;
  }
  tabs.splice(currentTabIndex, 1);
  currentTabIndex = 0;
  renderTabs();
  renderMessages();
  saveTabs();
}

function renderTabs() {
  const container = document.getElementById("tabs");
  container.innerHTML = "";
  tabs.forEach((tab, index) => {
    const div = document.createElement("div");
    div.className = "tab" + (index === currentTabIndex ? " active" : "");
    div.textContent = tab.name;
    div.onclick = () => {
      currentTabIndex = index;
      renderTabs();
      renderMessages();
    };
    container.appendChild(div);
  });
}

function renderMessages() {
  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML = "";
  const currentTab = tabs[currentTabIndex];
  currentTab.messages.forEach(({ sender, text }) => {
    appendMessage(sender, text, false);
  });
}

function appendMessage(sender, text, store = true) {
  const chatBox = document.getElementById("chat-box");
  const messageDiv = document.createElement("div");
  messageDiv.className = `message ${sender}`;
  messageDiv.innerHTML = text;

  messageDiv.onclick = () => {
    navigator.clipboard.writeText(messageDiv.innerText);
    alert("Message copied!");
  };

  chatBox.appendChild(messageDiv);
  chatBox.scrollTop = chatBox.scrollHeight;

  if (store) {
    tabs[currentTabIndex].messages.push({ sender, text });
    saveTabs();
  }
}

function getBotSystemMessage() {
  const botType = document.getElementById("bot-selector").value;
  switch (botType) {
    case "friendly":
      return { role: "system", content: "You are a cheerful, friendly chatbot who responds with warmth and encouragement." };
    case "professional":
      return { role: "system", content: "You are a formal, concise, and informative assistant suitable for business queries." };
    case "sarcastic":
      return { role: "system", content: "You respond with witty, sarcastic remarks but still answer the question accurately." };
    default:
      return { role: "system", content: "You are a helpful AI assistant." };
  }
}

async function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (!message) return;

  appendMessage("user", message);
  input.value = "";

  const loadingDiv = document.createElement("div");
  loadingDiv.className = "message bot loading-dots";
  loadingDiv.textContent = "Thinking...";
  document.getElementById("chat-box").appendChild(loadingDiv);
  document.getElementById("chat-box").scrollTop = chatBox.scrollHeight;

  try {
    const response = await fetch("http://localhost:3000/chat", {

      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          getBotSystemMessage(),
          ...tabs[currentTabIndex].messages.map(m => ({
            role: m.sender === "user" ? "user" : "assistant",
            content: m.text
          })),
          { role: "user", content: message }
        ]
      })
    });

    if (!response.ok) throw new Error("API request failed");

    const data = await response.json();
    const botMessage = data.choices[0].message.content;

    loadingDiv.remove();
    appendMessage("bot", botMessage);
  } catch (error) {
    loadingDiv.remove();
    appendMessage("bot", "Oops! Something went wrong.");
    console.error("Error:", error);
  }
}

function startVoice() {
  if (!('webkitSpeechRecognition' in window)) {
    alert("Your browser does not support voice input.");
    return;
  }

  const recognition = new webkitSpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.start();

  recognition.onresult = event => {
    const transcript = event.results[0][0].transcript;
    document.getElementById("user-input").value = transcript;
  };

  recognition.onerror = event => {
    alert("Voice input error: " + event.error);
  };
}

function handleFile(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    let content;
    if (file.type.startsWith("image/")) {
      content = `<img src="${e.target.result}" alt="${file.name}" />`;
    } else {
      content = `<a href="${e.target.result}" download="${file.name}">${file.name}</a>`;
    }

    appendMessage("user", content, true);
  };

  if (file.type.startsWith("image/") || file.type.startsWith("text/")) {
    reader.readAsDataURL(file);
  } else {
    alert("Unsupported file type.");
  }

  event.target.value = "";
}

function exportChat() {
  const currentTab = tabs[currentTabIndex];
  const content = currentTab.messages.map(m =>
    `${m.sender.toUpperCase()}: ${m.text.replace(/<[^>]+>/g, '')}`
  ).join("\n\n");

  const blob = new Blob([content], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${currentTab.name.replace(/\s+/g, "_")}_chat.txt`;
  a.click();
  URL.revokeObjectURL(a.href);
}

function toggleDarkMode() {
  const isDark = document.body.classList.toggle("dark-mode");
  localStorage.setItem("darkMode", isDark);
  document.getElementById("theme-toggle").textContent = isDark ? "☀️ Light Mode" : "🌓 Dark Mode";
  toggleMenu();
}

function clearChat() {
  if (confirm("Clear all messages in this tab?")) {
    tabs[currentTabIndex].messages = [];
    saveTabs();
    renderMessages();
  }
}

function toggleMenu() {
  document.getElementById("dropdown-menu").classList.toggle("hidden");
}

function showTabHistory() {
  const currentTab = tabs[currentTabIndex];
  const history = currentTab.messages.map((m, i) =>
    `${i + 1}. ${m.sender.toUpperCase()}: ${m.text.replace(/<[^>]+>/g, '')}`
  ).join("\n\n");

  alert(history || "No messages in this tab yet.");
}

function changeBot() {
  const botType = document.getElementById("bot-selector").value;
  localStorage.setItem("botType", botType);
}

window.onload = () => {
  loadTabs();
  renderTabs();
  renderMessages();

  const isDark = localStorage.getItem("darkMode") === "true";
  if (isDark) {
    document.body.classList.add("dark-mode");
    document.getElementById("theme-toggle").textContent = "☀️ Light Mode";
  }

  const botType = localStorage.getItem("botType");
  if (botType) {
    document.getElementById("bot-selector").value = botType;
  }
};
